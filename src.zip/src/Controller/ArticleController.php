<?php

namespace App\Controller;

use App\Entity\Article;
use App\Repository\ArticleRepository;
use DateTime;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/article", name="app_article_")
 */
class ArticleController extends AbstractController
{
    /**
     * @Route("/", name="list")
     */
    public function index(ArticleRepository $repo): Response
    {


        return $this->render('article/list.html.twig', [
           "articles"=> $repo->findBy(["isPublished"=>true])
        ]);
    }

    /**
     * @Route("/authors", name="list_authors")
     */
    public function listAuthors(ArticleRepository $repo): Response
    {
        return $this->render('article/list-author.html.twig', [
           "authors"=> $repo->findAllAuthor()
        ]);
    }

    /**
     * @Route("/add", name="add")
     */
    public function add(EntityManagerInterface $em): Response
    {
        $article = new Article();
        $article->setTitle("Formation Java EE")
                ->setContent("blablablalbalbalbalblablblal")
                ->setAuthor("Pierre")
                ->setDatePublished(new DateTime())
                ->setIsPublished(True);

        //$em = $this->getDoctrine()->getManager();

        $em->persist($article);
        $em->flush();

        dd("Ajouter");
    }   

    /**
     * @Route("/{id}",name="detail",requirements={"id":"\d+"})
     */
    public function detail(Article $article){        
        return $this->render("/article/detail.html.twig",["article"=> $article ]);
    }
    
    /**
     * @Route("/auteur/{name}",name="author")
     */
    public function articlesAuthor(ArticleRepository $repo,$name){  
        return $this->render('article/list.html.twig', [
            "articles"=> $repo->findByAuthor($name),
            "author"=>$name
         ]);       
    }


    
    
 

}
